-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 10, 2023 at 05:35 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.0.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `question`
--

-- --------------------------------------------------------

--
-- Table structure for table `accounts`
--

CREATE TABLE `accounts` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `course` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `accounts`
--

INSERT INTO `accounts` (`id`, `username`, `password`, `email`, `course`) VALUES
(5, 'subhanshu', 'subhanshu@1', 'subhanshuuu@gmail.com', NULL),
(6, 'Rahul', 'subahnshu', 'subhanshuuu@gmail.com', 'MCA');

-- --------------------------------------------------------

--
-- Table structure for table `question`
--

CREATE TABLE `question` (
  `questionId` int(11) NOT NULL,
  `subjectId` int(11) DEFAULT NULL,
  `level` int(11) DEFAULT NULL,
  `question` text NOT NULL,
  `marks` int(11) NOT NULL,
  `unit` varchar(2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `question`
--

INSERT INTO `question` (`questionId`, `subjectId`, `level`, `question`, `marks`, `unit`) VALUES
(1, 4, 1, 'what is my name', 5, '2'),
(2, 4, 1, 'decribe the following word', 4, '2'),
(3, 4, 2, 'summarize the following', 4, '1'),
(4, 4, 6, 'Read Turing’s original paper on AI (Turing, 1950). In the paper, he discusses several', 2, '5'),
(5, 4, 4, 'objections to his proposed enterprise and his test for intelligence. Which objections still carry', 4, '4'),
(6, 4, 3, 'weight? Are his refutations valid? Can you think of new objections arising from developments', 3, '4'),
(7, 4, 2, 'Is AI a science, or is it engineering? Or neither or both? Explain.', 5, '4'),
(8, 4, 1, ' Define in your own words: (a) intelligence, (b) artificial intelligence, (c) agent, (d)', 3, '3'),
(9, 4, 3, 'Suppose that the performance measure is concerned with just the first T time steps of', 10, '3'),
(10, 4, 2, 'the environment and ignores everything thereafter. Show that a rational agent’s action may', 10, '2'),
(11, 4, 1, 'Explain why problem formulation must follow goal formulation. ', 3, '2'),
(12, 4, 3, 'Yourgoal is to navigate a robot out of a maze. The robot starts in the center of the maze', 3, '1'),
(13, 4, 6, 'wall. a. Formulate this problem. How large is the state space? b. In navigating a maze, the only place we need to turn is at the intersection of two or more corridors.', 1, '2'),
(14, 4, 2, 'Is the sentence ? x, y x = y valid? Explain.', 2, '3'),
(15, 4, 2, 'Write down a logical sentence such that every world in which it is true contains exactly one object', 3, '1'),
(16, 4, 4, 'Using the set axioms as examples, write axioms for the list domain, including all the constants, functions, and predicates mentioned in the chapter', 3, '4'),
(17, 4, 3, 'Explain what is wrong with the following proposed definition of adjacent squares in the wumpus world: ? x, y Adjacent([x, y], [x + 1, y]) ? Adjacent([x, y], [x, y + 1])', 2, '4'),
(18, 4, 6, 'Consider a state space where the start state is number 1 and each state k has two successors: numbers 2k and 2k +1 . a. Draw the portion of the state space for states 1 to 15. b. Suppose the', 10, '5'),
(19, 4, 1, 'who is ', 1, '2'),
(20, 4, 1, 'what is html', 5, '3'),
(21, 4, 2, 'Explain Triangle propert', 2, '1'),
(22, 5, 4, 'Yourgoal is to navigate a robot out of a maze. The robot starts in the center of the maze', 2, '5'),
(23, 7, 4, 'Yourgoal is to navigate a robot out of a maze. The robot starts in the center of the maze', 0, '3'),
(24, 4, 2, 'explain the question', 2, '5'),
(25, 4, 5, 'decide the following ', 2, '2');

-- --------------------------------------------------------

--
-- Table structure for table `subject`
--

CREATE TABLE `subject` (
  `subjectId` int(11) NOT NULL,
  `name` tinytext DEFAULT NULL,
  `userid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `subject`
--

INSERT INTO `subject` (`subjectId`, `name`, `userid`) VALUES
(1, 'Os', 5),
(2, 'Web', 5),
(3, 'Ww', 5),
(4, 'English', 5),
(5, 'Math', 5),
(6, 'Science', 5),
(7, 'Python', 5),
(8, 'Math', 6),
(9, 'English', 6);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accounts`
--
ALTER TABLE `accounts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `question`
--
ALTER TABLE `question`
  ADD PRIMARY KEY (`questionId`);

--
-- Indexes for table `subject`
--
ALTER TABLE `subject`
  ADD PRIMARY KEY (`subjectId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `accounts`
--
ALTER TABLE `accounts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `question`
--
ALTER TABLE `question`
  MODIFY `questionId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `subject`
--
ALTER TABLE `subject`
  MODIFY `subjectId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
